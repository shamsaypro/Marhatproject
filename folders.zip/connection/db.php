
<?php
$servername = "localhost"; 
$username = "root";       
$password = "";            
$dbname = "reesult_management"; 

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$sql = "SELECT * FROM users WHERE role = 'admin'";
$result = $conn->query($sql);

if ($result->num_rows == 0) {
    $first_name = "MARHAT";
    $last_name = "HEMED";
    $email = "hemedmarhat@gmail.com";
    $gender = "Female";
    $mobile = "0772568667";
    $role = "admin";
    $default_password = password_hash("12345678", PASSWORD_DEFAULT); 
    $status = "Unblock";
    $insert = "INSERT INTO users (first_name,last_name,email,gender,phone_number, password, role,status) 
               VALUES ('$first_name','$last_name','$email','$gender','$mobile', '$default_password', '$role','$status')";
    if ($conn->query($insert) === TRUE) {
        echo "";
    } else {
        echo "Error: " . $conn->error;
    }
}
?>

